globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/f1ac4_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b8062f57._.js",
    "static/chunks/f1ac4_next_dist_compiled_react-dom_b47f76d6._.js",
    "static/chunks/f1ac4_next_dist_compiled_react-server-dom-turbopack_6e9c2b5e._.js",
    "static/chunks/f1ac4_next_dist_compiled_next-devtools_index_751888a5.js",
    "static/chunks/f1ac4_next_dist_compiled_052d1c95._.js",
    "static/chunks/f1ac4_next_dist_client_554faf7d._.js",
    "static/chunks/f1ac4_next_dist_a4af8a23._.js",
    "static/chunks/f1ac4_@swc_helpers_cjs_4e3ccd7b._.js",
    "static/chunks/Prototype_frontend_a0ff3932._.js",
    "static/chunks/turbopack-Prototype_frontend_a0a9ebfd._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];