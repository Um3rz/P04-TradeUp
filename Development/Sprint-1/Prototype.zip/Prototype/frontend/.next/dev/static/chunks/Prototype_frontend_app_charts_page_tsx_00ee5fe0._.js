(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f1ac4_lightweight-charts_dist_lightweight-charts_development_mjs_7444e0c9._.js",
  "static/chunks/f1ac4_tailwind-merge_dist_bundle-mjs_mjs_b8cea880._.js",
  "static/chunks/f1ac4_@mui_material_esm_ed29c5a7._.js",
  "static/chunks/f1ac4_@mui_system_esm_bfa6d9e2._.js",
  "static/chunks/_b934b2fe._.js",
  "static/chunks/Prototype_frontend_c37ebfd0._.js"
],
    source: "dynamic"
});
