(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b8062f57._.js",
  "static/chunks/f1ac4_next_dist_compiled_react-dom_b47f76d6._.js",
  "static/chunks/f1ac4_next_dist_compiled_react-server-dom-turbopack_6e9c2b5e._.js",
  "static/chunks/f1ac4_next_dist_compiled_next-devtools_index_751888a5.js",
  "static/chunks/f1ac4_next_dist_compiled_052d1c95._.js",
  "static/chunks/f1ac4_next_dist_client_554faf7d._.js",
  "static/chunks/f1ac4_next_dist_a4af8a23._.js",
  "static/chunks/f1ac4_@swc_helpers_cjs_4e3ccd7b._.js"
],
    source: "entry"
});
