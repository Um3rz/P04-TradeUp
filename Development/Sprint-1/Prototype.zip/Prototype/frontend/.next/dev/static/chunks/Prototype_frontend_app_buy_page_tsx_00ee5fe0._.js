(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f1ac4_9f86b8c1._.js",
  "static/chunks/Prototype_frontend_9904ba32._.js"
],
    source: "dynamic"
});
