module.exports = [
"[project]/Prototype/frontend/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Prototype_frontend__next-internal_server_app__not-found_page_actions_997697eb.js.map