(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f1ac4_ae4b3c37._.js",
  "static/chunks/Prototype_frontend_7916e79f._.js"
],
    source: "dynamic"
});
