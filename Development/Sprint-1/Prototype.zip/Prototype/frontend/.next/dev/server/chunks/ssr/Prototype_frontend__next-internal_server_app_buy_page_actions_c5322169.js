module.exports = [
"[project]/Prototype/frontend/.next-internal/server/app/buy/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Prototype_frontend__next-internal_server_app_buy_page_actions_c5322169.js.map