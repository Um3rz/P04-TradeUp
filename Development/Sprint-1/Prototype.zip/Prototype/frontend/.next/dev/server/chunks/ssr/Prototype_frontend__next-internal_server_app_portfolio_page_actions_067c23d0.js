module.exports = [
"[project]/Prototype/frontend/.next-internal/server/app/portfolio/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Prototype_frontend__next-internal_server_app_portfolio_page_actions_067c23d0.js.map