(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f1ac4_12398d0f._.js",
  "static/chunks/Prototype_frontend_35f7720c._.js"
],
    source: "dynamic"
});
